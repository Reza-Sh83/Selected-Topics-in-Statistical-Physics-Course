# Rosenbrock function (to maximize -f)
rosenbrock <- function(x, y) {
  return(-( (1 - x)^2 + 100 * (y - x^2)^2 ))  # Negative for maximization
}

# Partial derivative with respect to x
dfdx <- function(x, y) {
  return(-(-2 * (1 - x) - 400 * x * (y - x^2)))  # Negative gradient
}

# Partial derivative with respect to y
dfdy <- function(x, y) {
  return(-200 * (y - x^2))  # Negative gradient
}

# Coordinate ascent algorithm
coordinate_ascent <- function(start_x = -1, start_y = 2, learning_rate = 0.001, tol = 1e-7, max_iter = 1000000) {
  x <- start_x
  y <- start_y
  for (iter in 1:max_iter) {
    old_x <- x
    old_y <- y
    # Step in the x direction
    x <- x + learning_rate * dfdx(old_x, old_y)
    # Step in the y direction
    y <- y + learning_rate * dfdy(old_x, old_y)
    # Check for convergence
    if (abs(x - old_x) < tol && abs(y - old_y) < tol) {
      break
    }
  }
  return(c(x, y, rosenbrock(x, y)))
}

# Run coordinate ascent
result <- coordinate_ascent()
cat("Optimal x:", result[1], "\n")
cat("Optimal y:", result[2], "\n")
cat("Maximum function value:", result[3], "\n")