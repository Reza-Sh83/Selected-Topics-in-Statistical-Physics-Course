# Load required libraries
library(MASS)     # For mvrnorm (multivariate normal)
library(ggplot2)  # For plotting

# Set random seed for reproducibility
set.seed(123)

# Define parameters for the 5 Gaussian components
n_components <- 5

# Mean vectors and covariance matrices for the 5 Gaussians
means <- matrix(c(2, 2,  0, -3, -5, 5,  3, -5, 0, 3), ncol = 2, byrow = TRUE)
covariances <- list(matrix(c(1, 0.5, 0.5, 1), ncol = 2),
                    matrix(c(1, -0.5, -0.5, 1), ncol = 2),
                    matrix(c(0.8, 0.3, 0.3, 0.8), ncol = 2),
                    matrix(c(1.2, 0.1, 0.1, 1.2), ncol = 2),
                    matrix(c(0.9, -0.3, -0.3, 0.9), ncol = 2))

# Mixing coefficients (sum should be 1)
mixing_coeffs <- c(0.2, 0.3, 0.1, 0.25, 0.15)

# Total number of points
n_points <- 1000

# Generate the mixture of Gaussians
generate_mixture <- function(n, means, covariances, mixing_coeffs) {
  component <- sample(1:n_components, size = n, replace = TRUE, prob = mixing_coeffs)
  data <- matrix(NA, nrow = n, ncol = 2)
  for (i in 1:n_components) {
    indices <- which(component == i)
    data[indices, ] <- mvrnorm(length(indices), mu = means[i, ], Sigma = covariances[[i]])
  }
  return(data)
}

# Generate data
data <- generate_mixture(n_points, means, covariances, mixing_coeffs)

# K-means clustering for estimating the component each point belongs to
kmeans_result <- kmeans(data, centers = n_components)

# Add the cluster information to the data
data_df <- data.frame(x = data[, 1], y = data[, 2], cluster = as.factor(kmeans_result$cluster))

# Plot the generated data with different colors for each component and ellipses
ggplot(data_df, aes(x = x, y = y, color = cluster)) +
  geom_point(alpha = 0.6, size = 1.5) +
  scale_color_manual(values = c("red", "blue", "green", "purple", "orange")) +
  stat_ellipse(aes(group = cluster), level = 0.95, linetype = "dashed", size = 1) +  # Add ellipses
  theme_minimal() +
  labs(title = "Generated Data from 5 Mixed Gaussians with Ellipses and Colors by Component",
       x = "X1", y = "X2", color = "Cluster")

# Calculate and display Mixing Coefficients (ϕ_k)
mixing_coeffs_est <- table(kmeans_result$cluster) / n_points
print("Estimated Mixing Coefficients (ϕ_k):")
print(mixing_coeffs_est)