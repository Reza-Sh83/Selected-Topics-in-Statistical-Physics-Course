# Load necessary libraries
library(ggplot2)
library(MASS)  # For mvrnorm

# Set seed for reproducibility
set.seed(42)

# Parameters for GMM
n <- 1000  # Total data points
K <- 3    # Number of clusters
dim_x <- 2  # Data dimension

# Generate synthetic data from a 2D Gaussian Mixture Model
true_means <- matrix(c(-4, -4, 4, 4, 0, 0), ncol = dim_x, byrow = TRUE)
true_covs <- list(matrix(c(1, 0.5, 0.5, 1), ncol = dim_x),
                  matrix(c(1, -0.3, -0.3, 1), ncol = dim_x),
                  matrix(c(1, 0, 0, 1), ncol = dim_x))
true_weights <- c(0.4, 0.4, 0.2)  # Mixing coefficients

# Generate data
data <- NULL
labels <- NULL
for (k in 1:K) {
  points <- mvrnorm(n = round(n * true_weights[k]), mu = true_means[k, ], Sigma = true_covs[[k]])
  data <- rbind(data, points)
  labels <- c(labels, rep(k, nrow(points)))
}
data <- as.data.frame(data)
colnames(data) <- c("x1", "x2")

# Plot true data distribution
ggplot(data, aes(x = x1, y = x2, color = factor(labels))) +
  geom_point(alpha = 0.6) +
  ggtitle("True GMM Data") +
  theme_minimal()

# ---- EM Algorithm for GMM ----

# Initialize parameters using K-means for means (mu)
kmeans_result <- kmeans(data, centers = K)
mu <- kmeans_result$centers
covariances <- lapply(1:K, function(k) diag(dim_x))  # Diagonal covariance matrices
weights <- rep(1/K, K)
responsibilities <- matrix(0, nrow = nrow(data), ncol = K)
elbo_values <- numeric(100)
epsilon <- 1e-6  # Convergence threshold

# Compute ELBO
evaluate_ELBO <- function(data, responsibilities, mu, covariances, weights) {
  elbo <- 0
  for (i in 1:nrow(data)) {
    likelihood <- 0
    for (k in 1:K) {
      likelihood <- likelihood + weights[k] * dmvnorm(as.numeric(data[i, ]), mean = mu[k, ], sigma = covariances[[k]])  # Correct 'Sigma' to 'sigma'
    }
    elbo <- elbo + log(likelihood)
  }
  return(elbo)
}

# Expectation-Maximization loop
for (iter in 1:100) {
  # E-Step: Compute responsibilities
  for (i in 1:nrow(data)) {
    total_likelihood <- 0
    for (k in 1:K) {
      responsibilities[i, k] <- weights[k] * dmvnorm(as.numeric(data[i, ]), mean = mu[k, ], sigma = covariances[[k]])  # Correct 'Sigma' to 'sigma'
      total_likelihood <- total_likelihood + responsibilities[i, k]
    }
    responsibilities[i, ] <- responsibilities[i, ] / total_likelihood  # Normalize responsibilities
  }

  # M-Step: Update parameters
  Nk <- colSums(responsibilities)

  for (k in 1:K) {
    mu[k, ] <- colSums(responsibilities[, k] * as.matrix(data)) / Nk[k]

    centered <- sweep(as.matrix(data), 2, mu[k, ], FUN = "-")
    covariances[[k]] <- t(centered) %*% (centered * responsibilities[, k]) / Nk[k]
    weights[k] <- Nk[k] / nrow(data)
  }

  # Compute ELBO and check convergence
  elbo_values[iter] <- evaluate_ELBO(data, responsibilities, mu, covariances, weights)
  if (iter > 1 && abs(elbo_values[iter] - elbo_values[iter - 1]) < epsilon) break
}

# ---- Visualization ----

# Assign clusters based on responsibilities
cluster_assignments <- apply(responsibilities, 1, which.max)
data$cluster <- as.factor(cluster_assignments)

# Plot clusters with ellipses
p <- ggplot(data, aes(x = x1, y = x2, color = cluster)) +
  geom_point(alpha = 0.6) +
  ggtitle("GMM Clusters (ELBO Maximization)") +
  theme_minimal() +
  stat_ellipse(aes(group = cluster), level = 0.95, linetype = "solid", color = "black")

print(p)