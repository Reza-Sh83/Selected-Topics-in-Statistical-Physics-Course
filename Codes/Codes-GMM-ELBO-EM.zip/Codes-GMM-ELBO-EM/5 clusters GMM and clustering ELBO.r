# Load necessary libraries
library(MASS)  # For mvrnorm

# Set seed for reproducibility
set.seed(42)

# Parameters
n <- 1000  # Total number of data points
K <- 5     # Number of clusters
dim_x <- 2 # Data dimension

# Define the true means and covariances for the 5 clusters
true_means <- matrix(c(
  -4, -4,   # Cluster 1 mean
  4, -4,    # Cluster 2 mean
  4, 4,     # Cluster 3 mean
  -4, 4,    # Cluster 4 mean
  0, 0      # Cluster 5 mean
), ncol = dim_x, byrow = TRUE)

true_covs <- list(
  matrix(c(1, 0.5, 0.5, 1), ncol = dim_x),  # Covariance for Cluster 1
  matrix(c(1, -0.3, -0.3, 1), ncol = dim_x), # Covariance for Cluster 2
  matrix(c(1, 0, 0, 1), ncol = dim_x),      # Covariance for Cluster 3
  matrix(c(1, 0.3, 0.3, 1), ncol = dim_x),  # Covariance for Cluster 4
  matrix(c(1, 0, 0, 1), ncol = dim_x)       # Covariance for Cluster 5
)

# Define the weights (proportions) for each cluster
true_weights <- c(0.2, 0.2, 0.2, 0.2, 0.2)

# Generate the data
data <- NULL
labels <- NULL

for (k in 1:K) {
  # Generate points for each cluster based on the multivariate normal distribution
  points <- mvrnorm(n = round(n * true_weights[k]), mu = true_means[k, ], Sigma = true_covs[[k]])
  data <- rbind(data, points)
  labels <- c(labels, rep(k, nrow(points)))
}

# Convert the data into a data frame and assign column names
data <- as.data.frame(data)
colnames(data) <- c("x1", "x2")
data$cluster <- as.factor(labels)

# Save the generated data to a CSV file on the desktop without header
write.table(data[, c("x1", "x2")], file = "~/Desktop/data-test.txt", row.names = FALSE, col.names = FALSE)

# Print the first few rows of the data
head(data)



# Load necessary libraries
library(MASS)
library(mclust)
library(ggplot2)

# Load the saved data into a data.frame (assuming it's space-delimited, adjust if necessary)
data <- read.table("~/Desktop/data-test.txt", header = FALSE)

# Ensure the data has exactly two columns
if (ncol(data) != 2) {
  stop("Error: The dataset must have exactly two columns.")
}

# Assign column names
colnames(data) <- c("X1", "X2")

# Fit GMM with automatic selection of clusters
gmm_model <- Mclust(data)

# Get the optimal number of clusters
optimal_G_BIC <- gmm_model$G
cat("Optimal number of clusters (BIC-based):", optimal_G_BIC, "\n")

# Add cluster labels
data$cluster <- as.factor(gmm_model$classification)

# Plot data with cluster colors
ggplot(data, aes(x = X1, y = X2, color = cluster)) +
  geom_point(size = 2, alpha = 0.7) +
  theme_minimal() +
  labs(title = "GMM Clustering", x = "X1", y = "X2") +
  theme(legend.title = element_blank())