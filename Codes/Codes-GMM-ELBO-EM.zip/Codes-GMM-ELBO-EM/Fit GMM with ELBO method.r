# Load necessary libraries
library(MASS)
library(mclust)  # This will automatically load the necessary functions for GMM
library(ggplot2)

# Set seed for reproducibility
set.seed(420)

# Parameters
n <- 4000  # Increase total number of data points for better resolution
K <- 9     # Number of clusters (initial guess)
dim_x <- 2  # Data dimension

# Generate random means for clusters within a fixed range
true_means <- matrix(runif(K * dim_x, min = -5, max = 5), ncol = dim_x, byrow = TRUE)

true_covs <- lapply(1:K, function(i) {
  # Generate a random symmetric matrix
  mat <- matrix(runif(dim_x^2, min = 0.0, max = 1), ncol = dim_x)
  sym_mat <- (mat + t(mat)) / 2  # Ensure symmetry
  diag(sym_mat) <- diag(sym_mat) + 0.5  # Ensure positive definiteness
  # Generate a random rotation matrix
  Q <- svd(matrix(rnorm(dim_x^2), ncol = dim_x))$u  # Random orthogonal matrix
  rotated_cov <- Q %*% sym_mat %*% t(Q)  # Apply rotation
  return(rotated_cov)
})

# Assign equal weights to clusters
true_weights <- rep(1/K, K)

# Generate the data
data <- NULL
labels <- NULL

for (k in 1:K) {
  points <- MASS::mvrnorm(n = round(n * true_weights[k]), mu = true_means[k, ], Sigma = true_covs[[k]])
  data <- rbind(data, points)
  labels <- c(labels, rep(k, nrow(points)))
}

# Convert data into a dataframe
data <- as.data.frame(data)
colnames(data) <- c("X1", "X2")
data$cluster <- as.factor(labels)

# Save generated data
write.table(data[, c("X1", "X2")], file = "~/Desktop/data-test.txt", row.names = FALSE, col.names = FALSE)

# Load saved data
data <- read.table("~/Desktop/data-test.txt", header = FALSE)
colnames(data) <- c("X1", "X2")

# ---- Use mclust for GMM and ELBO ----

# Fit a Gaussian Mixture Model using mclust for optimal G (number of clusters) using AIC and BIC
gmm_model <- Mclust(data, G = 1:20)  # Explore 1 to 20 clusters for more options
summary(gmm_model)

# Extract AIC, BIC, and optimal number of clusters
cat("AIC:", gmm_model$aic, "\n")
cat("BIC:", gmm_model$bic, "\n")

# Print the optimal number of clusters based on AIC and BIC
cat("Optimal number of clusters based on AIC:", gmm_model$G, "\n")
cat("Optimal number of clusters based on BIC:", gmm_model$G, "\n")

# ---- Initial and Final Weights ----
cat("Initial Weights:", rep(1/K, K), "\n")  # Display initial weights (uniform distribution)
cat("Final Weights after fitting the model:", gmm_model$parameters$pro, "\n")  # Display final weights from the fitted model

# ---- Plot the GMM clusters with enhancements ----

# Check if the data is empty or NA values
data_clean <- na.omit(data)

# Ensure data is not empty after cleaning
if (nrow(data_clean) == 0) {
  stop("The data has been cleaned and is empty. Check the input data.")
}

# Ensure the clustering results are present
if (is.null(gmm_model$classification)) {
  stop("Clustering results are NULL. Check if the model has converged properly.")
}

# Print first few classification results to check
print(head(gmm_model$classification))

# Ensure classification is correctly assigned
classification <- gmm_model$classification

# Custom color palette for optimal clusters (based on the GMM result)
custom_palette <- rainbow(gmm_model$G)

# Construct the plot
p <- ggplot(data_clean, aes(x = X1, y = X2, color = as.factor(classification))) +
  geom_point(alpha = 0.5, size = 1.5) +  # Smaller size, higher alpha for better visibility
  ggtitle("GMM Clusters - ELBO") +   # Title for the plot
  theme_minimal() +                    # Clean theme
  scale_color_manual(values = custom_palette) +  # Custom color palette
  stat_ellipse(aes(group = as.factor(classification)), 
               level = 0.95, 
               linetype = "solid", 
               color = "black", 
               alpha = 0.3) +         # Reduced transparency for better distinction
  labs(x = "X1", y = "X2", color = "Cluster") +  # Axis labels and color legend
  theme(legend.position = "top") +            # Place the legend at the top
  theme(plot.title = element_text(hjust = 0.5, size = 16))  # Center and size the title

# Print the plot
print(p)

# ---- ELBO approximation using the log-likelihood from the GMM fit ----
log_likelihood <- gmm_model$loglik
cat("Log-likelihood (related to ELBO):", log_likelihood, "\n")

# ---- Convergence Information ----
# Check the correct field for convergence
converged_status <- gmm_model$converged
cat("Convergence status of the EM algorithm:", converged_status, "\n")