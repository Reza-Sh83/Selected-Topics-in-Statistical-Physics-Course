# Load required libraries
library(tibble)
library(readr)  # For writing CSV files

# Set seed for reproducibility
set.seed(42)

# Parameters for gene expression data (TRIPLED)
n_genes <- 1500  # Number of genes (3x original size)
n_samples <- 30   # Number of samples (3x original size)
conditions <- c("A", "B", "C")  # Condition labels

# Means and standard deviations for each condition
means <- c(A = 10, B = 5, C = 2)  # Named vector for easy mapping
sds <- c(A = 2, B = 1.5, C = 2.5)

# Function to generate synthetic gene expression data with conditions per cell
generate_gene_expression <- function(n_genes, n_samples, means, sds, conditions) {
  # Assign each sample to a condition
  sample_conditions <- sample(conditions, n_samples, replace = TRUE)
  # Initialize matrices for expression data and condition labels
  data <- matrix(NA, nrow = n_genes, ncol = n_samples)
  condition_matrix <- matrix("", nrow = n_genes, ncol = n_samples)
  # Generate expression values and assign conditions per cell
  for (j in seq_len(n_samples)) {
    cond <- sample_conditions[j]  # Condition assigned to the sample
    data[, j] <- round(rnorm(n_genes, mean = means[cond], sd = sds[cond]))  # Round to nearest whole number
    condition_matrix[, j] <- cond  # Store condition label
  }
  # Combine expression values with conditions (formatted as "value (condition)")
  combined_data <- matrix(paste0(data, " (", condition_matrix, ")"), 
                          nrow = n_genes, ncol = n_samples)
  return(list(data = combined_data, conditions = sample_conditions))
}

# Generate tripled gene expression data
gene_expression_results <- generate_gene_expression(n_genes, n_samples, means, sds, conditions)

# Extract gene expression matrix
gene_expression_matrix <- gene_expression_results$data
condition_labels <- gene_expression_results$conditions  # One condition per sample

# Convert to data frame
gene_expression_df <- as.data.frame(gene_expression_matrix)
colnames(gene_expression_df) <- paste0("Sample_", seq_len(n_samples))  # Rename columns
rownames(gene_expression_df) <- paste0("Gene_", seq_len(n_genes))  # Rename rows

# Convert to tibble for better display
gene_expression_tbl <- as_tibble(gene_expression_df, rownames = "Gene")

# Save full dataset to CSV
write_csv(gene_expression_tbl, "gene_expression_triple_with_conditions.csv")

# Print confirmation message
cat("✅ Gene expression data (TRIPLED) saved as 'gene_expression_triple_with_conditions.csv'\n")

# Display a preview: 10 rows × 7 columns
print(gene_expression_tbl[1:10, 1:7])