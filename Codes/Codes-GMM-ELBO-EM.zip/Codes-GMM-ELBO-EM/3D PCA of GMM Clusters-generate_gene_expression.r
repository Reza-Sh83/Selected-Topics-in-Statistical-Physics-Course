# Load required libraries
library(tibble)
library(readr)  # For writing CSV files
library(MASS)  # For GMM
library(ggplot2)
library(plotly)
library(dplyr)
library(ClusterR)  # For Optimal_Clusters_GMM function
library(mclust)  # For Mclust function
library(cluster)  # For silhouette function

# Set seed for reproducibility
set.seed(4)

# Parameters for gene expression data (TRIPLED)
n_genes <- 150  # Number of genes (3x original size)
n_samples <- 5000   # Number of samples (3x original size)
conditions <- c("A", "B", "C")  # Condition labels

# Means and standard deviations for each condition
means <- c(A = 1, B = 3, C = 2)  # Named vector for easy mapping
sds <- c(A = 2, B = 1.5, C = 2)

# Function to generate synthetic gene expression data with conditions per cell
generate_gene_expression <- function(n_genes, n_samples, means, sds, conditions) {
  # Assign each sample to a condition
  sample_conditions <- sample(conditions, n_samples, replace = TRUE)
  # Initialize matrices for expression data and condition labels
  data <- matrix(NA, nrow = n_genes, ncol = n_samples)
  condition_matrix <- matrix("", nrow = n_genes, ncol = n_samples)
  # Generate expression values and assign conditions per cell
  for (j in seq_len(n_samples)) {
    cond <- sample_conditions[j]  # Condition assigned to the sample
    data[, j] <- round(rnorm(n_genes, mean = means[cond], sd = sds[cond]))  # Round to nearest whole number
    condition_matrix[, j] <- cond  # Store condition label
  }
  # Combine expression values with conditions (formatted as "value (condition)")
  combined_data <- matrix(paste0(data, " (", condition_matrix, ")"), 
                          nrow = n_genes, ncol = n_samples)
  return(list(data = combined_data, conditions = sample_conditions))
}

# Generate tripled gene expression data
gene_expression_results <- generate_gene_expression(n_genes, n_samples, means, sds, conditions)

# Extract gene expression matrix
gene_expression_matrix <- gene_expression_results$data
condition_labels <- gene_expression_results$conditions  # One condition per sample

# Convert to data frame (numeric part only for clustering and PCA)
gene_expression_df <- as.data.frame(gene_expression_matrix)

# Convert gene expression values to numeric by removing condition labels
numeric_data <- as.data.frame(t(gene_expression_df))  # Transpose to have samples as rows
numeric_data[] <- lapply(numeric_data, function(x) as.numeric(gsub("\\D", "", x)))  # Extract numeric values

# ---- Remove columns with zero variance ----
# Check for columns with zero variance
numeric_data <- numeric_data[, apply(numeric_data, 2, var, na.rm = TRUE) != 0]

# Manually scale the data before PCA and GMM clustering
scaled_data <- scale(numeric_data)  # This scales the numeric data

# ---- Perform PCA to reduce dimensionality to 3D ----
pca_result <- prcomp(scaled_data, scale = TRUE)  # Perform PCA on the scaled data

# Get the PCA data for 3D
pca_data <- as.data.frame(pca_result$x[, 1:3])  # Use the first 3 principal components

# ---- Preset number of clusters for GMM ----
k <- 4  # Set the desired number of clusters (replace with the cluster count you want)

# ---- Perform GMM clustering with preset k number of clusters ----
gmm_result <- Mclust(pca_data, G = k)

# Add clustering result to PCA data
pca_data$Cluster <- as.factor(gmm_result$classification)

# Add conditions (A, B, C) to the data for plotting
condition_rep <- rep(condition_labels, each = 1)  # One condition per sample
pca_data$Condition <- factor(condition_rep)

# ---- Plot the PCA results with clustering (3D) ----
p_3d <- plot_ly(pca_data, 
                x = ~PC1, 
                y = ~PC2, 
                z = ~PC3, 
                color = ~Cluster, 
                colors = rainbow(length(unique(pca_data$Cluster))),
                marker = list(size = 5), 
                type = "scatter3d",  # Explicitly set the trace type to scatter3d
                mode = "markers") %>%  # Set the mode to markers
  layout(scene = list(xaxis = list(title = "PC1"),
                      yaxis = list(title = "PC2"),
                      zaxis = list(title = "PC3")),
         title = "3D PCA of GMM Clusters")
print(p_3d)

# ---- Convergence Information (for GMM) ----
cat("Convergence status of the GMM algorithm:", gmm_result$converged, "\n")