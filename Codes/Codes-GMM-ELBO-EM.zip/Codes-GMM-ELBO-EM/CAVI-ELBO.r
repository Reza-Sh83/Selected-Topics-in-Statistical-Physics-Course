# Define Gaussian mixture model (same as before)
Pxz <- function(z, x) {
  return(dnorm(x, mean = z, sd = 1) * dnorm(z, mean = 0, sd = 1))
}

# Function to compute the log-sum-exp trick for numerical stability
log_sum_exp <- function(log_values) {
  max_log <- max(log_values)
  return(max_log + log(sum(exp(log_values - max_log))))
}

# Expectation computation with log-sum-exp trick
expectation_q_z_minus_i <- function(Pxz, q, data, i, z_i, grid) {
  log_probs <- sapply(grid, function(z_minus_i) {
    P_z_given_x <- Pxz(z_i, data)
    q_z_minus_i <- sum(sapply(setdiff(1:length(q), i), function(j) log(q[[j]](z_minus_i))))
    return(log(P_z_given_x) + q_z_minus_i)  # Log-space computation
  })
  return(log_sum_exp(log_probs))  # Return stabilized expectation
}

# ELBO computation using log-sum-exp trick
compute_elbo <- function(Pxz, q, data, grid) {
  log_expected_log_joint <- sapply(grid, function(z_m) {
    P_z_x <- Pxz(z_m, data)
    q_z <- sum(sapply(1:length(q), function(i) log(q[[i]](z_m))))
    return(log(P_z_x) + q_z)
  })
  log_expected_log_q <- sapply(grid, function(z_m) {
    q_z <- sum(sapply(1:length(q), function(i) log(q[[i]](z_m))))
    return(q_z)  # Corrected this line
  })
  return(log_sum_exp(log_expected_log_joint) - log_sum_exp(log_expected_log_q))
}

# CAVI function (same as before)
cavi <- function(Pxz, q_init, data, tol = 1e-6, max_iter = 100) {
  m <- length(q_init)
  q <- q_init
  elbo_values <- numeric(max_iter)
  grid <- seq(-10, 10, length.out = 200)

  for (iter in 1:max_iter) {
    for (i in 1:m) {
      log_q_new <- sapply(grid, function(z_i) expectation_q_z_minus_i(Pxz, q, data, i, z_i, grid))
      log_q_new <- log_q_new - log_sum_exp(log_q_new)  # Normalize in log-space
      q_new <- exp(log_q_new)  # Convert back to probability space
      q[[i]] <- approxfun(grid, q_new, rule = 2)  # Store as function
    }
    elbo <- compute_elbo(Pxz, q, data, grid)
    elbo_values[iter] <- elbo
    # Check for convergence
    if (iter > 1 && abs(elbo_values[iter] - elbo_values[iter - 1]) < tol) {
      cat("Converged at iteration:", iter, "\n")
      break
    }
  }
  return(list(q = q, elbo = elbo_values[1:iter]))
}

# Example usage with a far data point
data <- 5  # Observed data point far from the prior mean (0)

q_init <- list(
  approxfun(seq(-10, 10, length.out = 200), dnorm(seq(-10, 10, length.out = 200), mean = 0, sd = 1), rule = 2),
  approxfun(seq(-10, 10, length.out = 200), dnorm(seq(-10, 10, length.out = 200), mean = 0, sd = 1), rule = 2)
)

# Run CAVI
result <- cavi(Pxz, q_init, data)

# Print ELBO values over iterations
print(result$elbo)

# Plot the initial Gaussian mixture p(z)
grid <- seq(-10, 10, length.out = 200)

# Initial p(z) (prior) is a standard normal distribution
pz_values <- dnorm(grid, mean = 0, sd = 1)

# Normalize pz_values (prior)
pz_normalized <- pz_values / sum(pz_values)  # Normalize the prior

# Plot the final variational distribution q(z)
q_values <- sapply(grid, function(z) result$q[[2]](z))

# Normalize q_values (variational distribution)
q_normalized <- q_values / sum(q_values)  # Normalize the variational distribution

# Plot both distributions
plot(grid, pz_normalized, type = "l", col = "blue", lty = 2, 
     main = "Variational Distribution q(z) and Initial p(z)", 
     ylab = "Probability Density", xlab = "z")
lines(grid, q_normalized, col = "red", lty = 1)
legend("topright", legend = c("Initial p(z)", "Final q(z)"), 
       col = c("blue", "red"), lty = c(2, 1))