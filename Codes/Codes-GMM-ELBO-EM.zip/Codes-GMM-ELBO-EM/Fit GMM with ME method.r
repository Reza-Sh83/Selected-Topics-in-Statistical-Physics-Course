# Load necessary libraries
library(MASS)  
library(mclust)
library(ggplot2)

# Set seed for reproducibility
set.seed(42)

# Parameters
n <- 2000  # Total number of data points
K <- 9     # Number of clusters
dim_x <- 2 # Data dimension

# Generate random means for clusters within a fixed range
true_means <- matrix(runif(K * dim_x, min = -5, max = 5), ncol = dim_x, byrow = TRUE)

# Generate random covariance matrices
true_covs <- lapply(1:K, function(i) {
  mat <- matrix(runif(dim_x^2, min = -0.5, max = 1), ncol = dim_x)
  return(crossprod(mat))  # Ensure positive semi-definiteness
})

# Compute initial standard deviations from covariance matrices
true_stds <- lapply(true_covs, function(cov) sqrt(diag(cov)))  # Use lapply instead of sapply

# Assign equal weights to clusters
true_weights <- rep(1/K, K)

# Generate the data
data <- NULL
labels <- NULL

for (k in 1:K) {
  points <- MASS::mvrnorm(n = round(n * true_weights[k]), mu = true_means[k, ], Sigma = true_covs[[k]])
  data <- rbind(data, points)
  labels <- c(labels, rep(k, nrow(points)))
}

# Convert data into a dataframe
data <- as.data.frame(data)
colnames(data) <- c("X1", "X2")
data$cluster <- as.factor(labels)

# Save generated data
write.table(data[, c("X1", "X2")], file = "~/Desktop/data-test.txt", row.names = FALSE, col.names = FALSE)

# Load saved data
data <- read.table("~/Desktop/data-test.txt", header = FALSE)
colnames(data) <- c("X1", "X2")

# Fit Gaussian Mixture Model using Expectation-Maximization (EM)
gmm_model <- Mclust(data)

# Get optimal number of clusters using BIC
optimal_G_BIC <- gmm_model$G
optimal_G_AIC <- optimal_G_BIC  # Use the selected number of clusters from BIC

cat("Optimal number of clusters (BIC-based):", optimal_G_BIC, "\n")
cat("Optimal number of clusters (AIC-based):", optimal_G_AIC, "\n")

# Extract final GMM parameters
final_means <- gmm_model$parameters$mean
final_weights <- gmm_model$parameters$pro

# Print original and final cluster properties
cat("\nOriginal Means:\n")
print(true_means)
cat("\nFinal Means:\n")
print(final_means)

cat("\nOriginal Standard Deviations:\n")
print(true_stds)
cat("\nFinal Weights:\n")
print(final_weights)

# Add cluster labels from GMM
data$cluster <- as.factor(gmm_model$classification)

# Create the plot
p <- ggplot(data, aes(x = X1, y = X2, color = cluster)) +
  geom_point(size = 2, alpha = 0.7) +
  theme_minimal() +
  labs(
    title = paste("GMM Clustering\nOptimal Clusters (AIC):", optimal_G_AIC, 
                  "\nOptimal Clusters (BIC):", optimal_G_BIC),
    x = "X1", y = "X2"
  ) +
  theme(legend.title = element_blank())

# Add ellipses only if there are multiple clusters
if (length(unique(data$cluster)) > 1) {
  p <- p + stat_ellipse(aes(color = cluster), type = "norm", size = 1)
}

# Print the plot
print(p)