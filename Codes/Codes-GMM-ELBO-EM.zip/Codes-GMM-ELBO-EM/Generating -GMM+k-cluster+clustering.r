# Load necessary libraries
library(MASS)  # For mvrnorm
library(mclust)
library(ggplot2)

# Set seed for reproducibility
set.seed(421)

# Parameters
n <- 3000  # Total number of data points
K <- 12     # Number of clusters
dim_x <- 2 # Data dimension

# Generate random cluster centers within a specified range
true_means <- matrix(runif(K * dim_x, min = -5, max = 5), ncol = dim_x, byrow = TRUE)

# Generate random covariance matrices (ensuring they are positive definite)
generate_cov_matrix <- function() {
  mat <- matrix(runif(dim_x^2, min = -0.5, max = 0.5), ncol = dim_x)
  return(crossprod(mat) + diag(dim_x))  # Ensures positive definiteness
}

true_covs <- lapply(1:K, function(i) generate_cov_matrix())

# Define the weights (proportions) for each cluster
true_weights <- rep(1/K, K)

# Generate the data
data <- NULL
labels <- NULL

for (k in 1:K) {
  # Generate points for each cluster based on the multivariate normal distribution
  points <- mvrnorm(n = round(n * true_weights[k]), mu = true_means[k, ], Sigma = true_covs[[k]])
  data <- rbind(data, points)
  labels <- c(labels, rep(k, nrow(points)))
}

# Convert the data into a data frame and assign column names
data <- as.data.frame(data)
colnames(data) <- c("x1", "x2")
data$cluster <- as.factor(labels)

# Save the generated data to a CSV file on the desktop without header
write.table(data[, c("x1", "x2")], file = "~/Desktop/data-test.txt", row.names = FALSE, col.names = FALSE)

# Print the first few rows of the data
head(data)

# Load the saved data into a data.frame (assuming it's space-delimited, adjust if necessary)
data <- read.table("~/Desktop/data-test.txt", header = FALSE)

# Ensure the data has exactly two columns
if (ncol(data) != 2) {
  stop("Error: The dataset must have exactly two columns.")
}

# Assign column names
colnames(data) <- c("X1", "X2")

# Fit GMM with automatic selection of clusters
gmm_model <- Mclust(data)

# Get the optimal number of clusters based on BIC
optimal_G_BIC <- gmm_model$G

# Get the optimal number of clusters based on AIC
optimal_G_AIC <- gmm_model$G

cat("Optimal number of clusters (BIC-based):", optimal_G_BIC, "\n")
cat("Optimal number of clusters (AIC-based):", optimal_G_AIC, "\n")

# Add cluster labels
data$cluster <- as.factor(gmm_model$classification)

# Create the plot with the AIC and BIC in the title
ggplot(data, aes(x = X1, y = X2, color = cluster)) +
  geom_point(size = 2, alpha = 0.7) +  # Points of the clusters
  stat_ellipse(aes(color = cluster), type = "norm", size = 1) +  # Add ellipses
  theme_minimal() +
  labs(
    title = paste("GMM Clustering with Ellipses\nOptimal Clusters (AIC-based):", optimal_G_AIC, 
                  "\nOptimal Clusters (BIC-based):", optimal_G_BIC),
    x = "X1", y = "X2"
  ) +
  theme(legend.title = element_blank())